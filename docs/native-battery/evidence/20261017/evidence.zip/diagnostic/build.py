#!/usr/bin/env python3
"""Read-only diagnostic; stage inputs with the exact Battery recipe first.

Example: python build.py --utilities /path/to/Utilities --inputs /path/to/recipe/inputs --output /tmp/battery-idle-run
No source correction is applied. All production dependencies are checked against Git objects.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,importlib.util,shlex,os
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--utilities',type=Path,default=Path('/tmp/battery-native-20261017'))
p.add_argument('--inputs',type=Path,default=Path('/tmp/battery-native-recipe-check5/inputs'))
p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'run')
p.add_argument('--sanitize',action='store_true')
p.add_argument('--system-repo',type=Path,default=Path('/tmp/quick-native-adapter-20261017'))
p.add_argument('--bridges-repo',type=Path,default=Path('/tmp/native-settings-target-20261017/bridges'))
p.add_argument('--runtime-repo',type=Path,default=Path('/tmp/wave-paired-20261017/runtime'))
p.add_argument('--profile-repo',type=Path,default=Path('/tmp/wave-sd-successor/product'))
a=p.parse_args();R=a.utilities.resolve();D=Path(__file__).resolve().parent;I=a.inputs.resolve();O=a.output.resolve();O.mkdir(exist_ok=True,parents=True)
TREE='33757f8e9d6cb548e42e8bf2a975d50d6663903e'
spec=importlib.util.spec_from_file_location('recipe',R/'scripts/build_native_battery_qualification.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
repos={'utilities':R,'utilities-baseline':R,'system':a.system_repo,'bridges':a.bridges_repo,'runtime':a.runtime_repo,'profile_source':a.profile_repo}
pins={'utilities':TREE,'utilities-baseline':m.BASE,**m.PINS}
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda r,*args:subprocess.check_output(['git','-C',str(r),*args])
assert git(R,'rev-parse','HEAD^{tree}').decode().strip()==TREE
for rel in ['scripts/build_native_battery_qualification.py','profiles/native-battery-qualification.json','profiles/native-battery-baseline-manifest.json']:
 assert (R/rel).read_bytes()==git(R,'show',TREE+':'+rel),rel
m.validate_profile(json.loads((R/m.PROFILE_PATH).read_text()),(R/'profiles/native-battery-baseline-manifest.json').read_bytes())
incs=[I/'system/lib/PortableApps/include',I/'system/lib/NativeApps/include',R/'Apps',I/'utilities-baseline/Apps',I/'utilities-baseline/lib/Alarm/include',I/'utilities-baseline/lib/Contexts/include',I/'profile_source/profiles/shared-editor-inputs',I/'runtime/sdk/app',I/'bridges/sdk/app',I/'bridges/sdk/driver',I/'bridges/include']
flags=m.define_arguments(True)+['-I'+str(p) for p in incs]
for name,path in {'PERIPHERALS':R/'test/native_apps/battery_native_peripherals.h','ATOMIC':R/'tests/utility_atomic_transport.h','APP':R/'Apps/battery.c','ADAPTER':I/'system/lib/PortableApps/src/adapter.c'}.items():flags+=['-DBATTERY_DIAG_'+name+'='+json.dumps(str(path))]
for s in m.FORCED: x,y=s.split(':');flags+=['-include',str(I/x/y)]
sources=[D/'probe.c',D/'adapter_probe.c',*[I/'bridges/apps/clock'/s for s in ['portable_navigation.c','portable_sleep.c']],*[I/'system/lib/PortableApps/src'/s for s in ['quick_actions.c','quick_render.c','quick_session.c','quick_radios.c']]]
closure={}; paths={}
for source in sources:
 raw=subprocess.check_output(['cc','-std=gnu11','-MM',*flags,str(source)],text=True)
 for token in shlex.split(raw.replace('\\\n',' ').split(':',1)[1]):
  q=Path(token).resolve();data=q.read_bytes()
  if q.is_relative_to(D): owner='diagnostic';rel=str(q.relative_to(D))
  elif q.is_relative_to(R): owner='utilities';rel=str(q.relative_to(R))
  else:
   assert q.is_relative_to(I),q
   owner,*parts=q.relative_to(I).parts;rel='/'.join(parts)
   if owner=='system' and rel in ['lib/PortableApps/include/RiscRuntimeV1.h','lib/PortableApps/include/RiscKeyValueAtomicV1.h']: owner='runtime';rel='sdk/app/'+q.name
  if owner!='diagnostic': assert data==git(repos[owner],'show',pins[owner]+':'+rel),q
  identity=owner+':'+rel;closure[identity]=sha(data);paths[q]=sha(data)
assert m.REQUIRED_CLOSURE<=closure.keys(),m.REQUIRED_CLOSURE-closure.keys()
base=['cc','-std=gnu11','-O1','-g','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-variable',*flags]
if a.sanitize:base+=['-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer','-no-pie']
binary=O/'probe';command=base+list(map(str,sources))+['-Wl,--wrap=portable_app_alarm_sleep','-o',str(binary)]
(O/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (O/'build.log').open('w') as f:subprocess.run(command,check=True,stdout=f,stderr=subprocess.STDOUT)
cases=[0,1,2,3,4,6,7,8,9,10,11,12,13];results=[]
for mode in cases:
 cmd=[str(binary),str(mode)]
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'})
 log=r.stdout;(O/f'case{mode}.log').write_text(log)
 results.append({'case':mode,'exit_code':r.returncode,'command':cmd,'log_sha256':sha(log.encode())})
 if r.returncode:raise RuntimeError(f'case {mode}: {log}')
for q,h in paths.items():assert sha(q.read_bytes())==h,q
assert git(R,'rev-parse','HEAD^{tree}').decode().strip()==TREE
receipt={'kind':'diagnostic control witnesses; expected defects remain unfixed','utilities_commit':git(R,'rev-parse','HEAD').decode().strip(),'utilities_tree':TREE,'pins':m.PINS,'full_profile_defines':m.define_arguments(True),'production_translation_units':m.SOURCES,'hardware_tested':False,'target_instructions_executed':False,'sanitized':a.sanitize,'sanitizer_environment':{'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'},'sanitizer_limit':'LeakSanitizer is unsupported under this ptrace environment; separate initial probe records its fatal environment error. ASan and UBSan run normally. Resource counters and immutable framebuffer assertions remain enabled.','build_script_sha256':sha(Path(__file__).read_bytes()),'compiled_dependency_sha256':dict(sorted(closure.items())),'source_unchanged':True,'results':results,'binary_sha256':sha(binary.read_bytes()),'binary_retained':False,'production_source_edits':False,'correction_applied':False}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');binary.unlink()
print(f'{len(cases)} full-profile diagnostic cases passed expected assertions; sanitized={a.sanitize}; sources unchanged; binary removed')
