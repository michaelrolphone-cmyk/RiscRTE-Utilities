# Battery automatic-idle and presentation diagnostic

## Result

The exact full-feature native Battery reaches the existing shared cancellation-pass idle defect through its alarm path. A separate asynchronous first-presentation witness accepts a Details tap before that page is visible. Both are release blockers; the checks preserve the failures as diagnostic observations and apply no correction.

Source: Utilities commit `5fcc973233919c4b9739c1cd61d29f6d48517aae`, tree `33757f8e9d6cb548e42e8bf2a975d50d6663903e`; System `fd9a028c5d38eb517c1328b869684c4330a5d4d9`; Watch bridges `6e82fdcaec0b73ed700d2104cfb4d94f011c19d4`; Runtime SDK `48229bd1593a2e24e95bf4537b495ee615990fd3`; pinned alarm profile `b9862e1379813a0914d4926ef59a3feb6fcf656a`.

`build.py` uses every selector and production translation unit from the checked-in full-feature recipe, including real Watch navigation and sleep bridges. `adapter_probe.c` includes the unchanged adapter to expose read-only state and direct-poll controls. `probe.c` includes unchanged Battery and uses modeled providers. The linker wrapper records entry into `portable_app_alarm_sleep` and then invokes the real bridge; it does not replace the sleep decision or bridge implementation. The modeled `power.sleep` callback is the only physical Light endpoint. Automatic idle stays enabled; no X4 gate or manual-only suppression is added.

There are 13 cases in each normal and ASan/UBSan run. Receipts verify 138 compiled dependencies, including the two diagnostic translation units and the existing test-provider helpers. Every non-diagnostic dependency is compared to its exact Git object before building, then checked unchanged after running. No production source, Settings source, shared correction, or capability manifest is modified. Binaries are removed after hashing.

## Full app_main idle witness and controls

- Case 11: first frame visible at 4 ms; a short alarm cue starts at 60,001 and finishes at 60,005. A genuinely fresh DOWN is captured at 60,005, after the cue's input-reset watermark and long after the Battery page is visible. The cancellation is reduced first. The subscription is closed with one held raw contact and one queued DOWN at 60,006; the real Watch bridge enters modeled `light_sleep_set` at 60,009. Bridge/Light counts are 1/1. No denied grants, retention, or resource leak occurs.
- Case 12: no cue; a fresh held DOWN at 60,001 updates activity and prevents automatic sleep. Bridge/Light counts 0/0. Its later release opens Details.
- Case 13: cue occurs earlier, 59,001 to 59,005, allowing an ordinary neutral pass to consume cancellation before a fresh DOWN at 60,000. Bridge/Light counts 0/0. Its later release opens Details.
- Cases 0 to 4 are narrower adapter controls: ordinary idle reaches Light; fresh contact without cancellation prevents it; pending post-cue cancellation permits it; an explicit preceding neutral pass prevents it; idle with no contact after a cue remains allowed. Cases 2/3 use a deliberate clock advance between controller passes; case 11 is the end-to-end natural-polling witness and does not use that shortcut.

The former Settings startup-reset witness alone was insufficient: Battery's initial presentation does not call that Settings-specific reset. The alarm cue establishes Battery's actual reachable boundary.

### Source chain

1. Battery calls the production poll every 50 ms: [battery_power.inc lines 370–374](https://github.com/michaelrolphone-cmyk/RiscRTE-Utilities/blob/b5791106a80dacb41607da3f762696d86ee04790/Apps/battery_power.inc#L370-L374).
2. Short cue completion calls `alarm_cancel_input`, which calls `input_reset`: [alarm.inc lines 31–38 and 372–378](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/fd9a028c5d38eb517c1328b869684c4330a5d4d9/lib/PortableApps/src/alarm.inc#L372-L378).
3. Reset sets cancellation pending and snapshots the boundary. The next reduction returns cancellation before reading the newer queued edge: [PortableTouch.h lines 107–115 and 192–202](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/fd9a028c5d38eb517c1328b869684c4330a5d4d9/lib/PortableApps/include/PortableTouch.h#L107-L115).
4. Activity updates require a valid down/began/released sample; the idle guard checks navigation and logical down/released but not pending cancellation/progress or unconsumed raw contact: [adapter.c lines 772–777, 2242–2273, 2341–2366](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/fd9a028c5d38eb517c1328b869684c4330a5d4d9/lib/PortableApps/src/adapter.c#L2341-L2366).
5. The real idle path pauses background services, drains ownership, suspends radios, closes touch, and calls the real sleep bridge: [adapter.c idle_sleep](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/fd9a028c5d38eb517c1328b869684c4330a5d4d9/lib/PortableApps/src/adapter.c#L1655-L1820); [Watch portable_sleep.c lines 245–307](https://github.com/michaelrolphone-cmyk/RiscRTE-Watch/blob/6e82fdcaec0b73ed700d2104cfb4d94f011c19d4/apps/clock/portable_sleep.c#L245-L307).

## Presentation ownership discriminator

- Case 6, asynchronous provider: raw DOWN 50 / UP 75 ms while token 1 is pending; Details becomes the controller state at 76 ms; first presentation completes at 121 ms. This is acceptance before initial visibility, not proof of a queued event delivered after completion.
- Case 7, same asynchronous provider with a fresh post-visible tap: visibility 119; DOWN 201 / UP 226; Details 227 ms. The valid control remains accepted.
- Case 9, synchronous-provider control with the same full-feature compile selectors: pre-visible DOWN 64 / UP 80 are queued during blocking presentation; first visibility 120; Details remains unopened. This startup control must not be mislabeled as another failure. Quick starts with a neutral gate, so this does not establish a general per-page presentation watermark.
- Case 10, synchronous fresh control: visibility 120; DOWN 203 / UP 228; Details 229 ms.

The asynchronous source path returns immediately after storing the pending token ([adapter.c 1577–1583](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/fd9a028c5d38eb517c1328b869684c4330a5d4d9/lib/PortableApps/src/adapter.c#L1577-L1583)); pending progress remains successful ([1331–1352](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/fd9a028c5d38eb517c1328b869684c4330a5d4d9/lib/PortableApps/src/adapter.c#L1331-L1352)). Battery continues polling and immediately applies the Details hit ([battery_power.inc 421–427](https://github.com/michaelrolphone-cmyk/RiscRTE-Utilities/blob/b5791106a80dacb41607da3f762696d86ee04790/Apps/battery_power.inc#L421-L427)). Its `utility_frame_ready` render guard preserves framebuffer ownership but does not gate action ownership.

Related evidence: Mycelium `native-input-presentation-ownership-20261017`, revision 2, was read. Its Settings capture-boundary results preserve compatible contact continuation and reject pre-watermark new starts; they are not imported as Battery qualification. The linked source is [Settings capture-boundary baseline](https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/blob/34f3d20e9c2bd7e21e7fcb3f03282e164565d129/docs/native-settings/capture-boundary-baseline.json). The two Battery timing controls above distinguish the actual observed behavior without replaying any Settings/shared correction.

## Grant and qualification limits

All fifteen capability types/versions remain unchanged. The modeled provider dispatch enforces the selected instances: ordinary and atomic key/value namespace 1; Wi-Fi instance 15; Bluetooth instance 16; other requested physical/service capabilities instance 0. No sixteenth `app.catalog` grant is supplied. Contexts catalog-dependent launches remain outside this manifest's authority.

A type/version alone is insufficient for portable compatibility. This cohort requires Runtime atomic backend support and an app/namespace binding. Product `d0f95bfcfbef90df58f1bd6e8a3cfe5c495ab8eb` enables `RISC_RUNTIME_ATOMIC_KEY_VALUE=1` ([native-idf61.cmake line 25](https://github.com/michaelrolphone-cmyk/RiscRTE-Wavshare-S3-Touch-AMOLED-2.06/blob/d0f95bfcfbef90df58f1bd6e8a3cfe5c495ab8eb/profiles/native-idf61.cmake#L25)) and explicitly registers `battery` namespace 1 ([native-idf61-settings.h line 4](https://github.com/michaelrolphone-cmyk/RiscRTE-Wavshare-S3-Touch-AMOLED-2.06/blob/d0f95bfcfbef90df58f1bd6e8a3cfe5c495ab8eb/profiles/native-idf61-settings.h#L4)). Runtime `48229bd...:src/bootstrap/Runtime.cpp:522–525` rejects an atomic grant unless API=1, namespace is nonzero, and `atomicBinding(policy.id, namespace)` exists. These exact product objects were read for the diagnostic; they do not prove arbitrary products are supported or grant a new candidate production admission.

Provider suffixes also matter. The real bridge checks brightness support, timed power sleep, display power, and the pinned alarm sleep-resume suffix. Case 8 keeps `alarm.service@1` but supplies only its valid base prefix: the bridge is reached once and cleanly refuses, with zero Light entries. Thus the fifteen manifest pairs do not alone guarantee physical sleep compatibility. Motion enrollment needs the selected wake/tap and power wake-set interfaces. The ordinary success mock supplies them and returns a GPIO wake, not a timer/deep transition.

This is a bounded host diagnostic at 240×240 RGB565 with safe provider defaults, valid grant identities and checked releases. Real low-battery crossing writes, arbitrary Quick/Contexts policy changes, fingerprint banks, RF transmission, product Runtime admission, hardware timing, and physical sleep/wake are not qualified by it. Their code and feature selectors remain compiled. No production target instructions are executed. Existing broader geometry/controller/ELF receipts remain separate evidence.

## Reproduce and inspect

Stage the recipe's exact external inputs, then run:

```
python build.py --utilities /path/to/Utilities --inputs /path/to/qualification/inputs --output /tmp/battery-idle-normal
python build.py --utilities /path/to/Utilities --inputs /path/to/qualification/inputs --sanitize --output /tmp/battery-idle-sanitized
```

Supply `--system-repo`, `--bridges-repo`, `--runtime-repo`, and `--profile-repo` if Git-object repositories are elsewhere. They are used read-only. The Utilities checkout must have the exact recorded tree. Each run retains its full compile command, per-case execution command, combined chronological log, source hashes, and receipt.

ASan and UBSan are enabled in the sanitized run; LeakSanitizer is disabled because the initial explicit attempt failed under ptrace. `environment/leak-sanitizer-unsupported.log` preserves that limitation. Provider-owned framebuffer hashes, no reacquire/release while pending, zero final grants/frames/subscriptions/tokens, and zero retention remain asserted independently. These are diagnostic assertions that reproduce known unsafe behavior, not a green release verdict.
