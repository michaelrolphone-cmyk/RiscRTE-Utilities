#define main safety_test_main
#include "../RiscRTE-Utilities/test/native_apps/rf_shared_input_safety_test.c"
#undef main
int main(void){
 direct_setup();rf_capture_identity original=prefs.identity;uint32_t before=cfa_identity();
 prefs.identity.settings_id=1;uint8_t bytes[RF_PREFERENCES_SIZE];rf_preferences restored={0};
 assert(rf_preferences_encode(&prefs,bytes)&&rf_preferences_decode(&restored,bytes,sizeof(bytes)));
 prefs=restored;assert(!rf_identity_equal(&original,&prefs.identity));
 printf("accepted persisted settings_id=%u legacy_equal=%d shared_hash_before=%u shared_hash_after=%u\n",prefs.identity.settings_id,rf_identity_equal(&original,&prefs.identity),before,cfa_identity());fflush(stdout);
 assert(before!=cfa_identity());return 0;
}
