# Draft PR: Preserve shared capture priority during neural checkpointing

This is local draft text only. No branch push or PR creation is authorized or performed for T040.

## Branch and source

- Repository: michaelrolphone-cmyk/RiscRTE-Utilities
- Proposed base: main, reconciled at `6b2047500905f8f45087cb49989103a926fc5c63`
- Local branch: `tasker/t040-neural-reconcile-20261021`
- Local commit: `601fa56324e1a1c0c4b4f6d51b13b6a8c6ae54e2`
- Work: [T040](https://tasker-workboard.hazy-auk-4334.chatgpt.site/?task=T040)

## Summary

The acoustic neural matcher requested by T040 is already implemented in PR37. Current source also preserves the externally developed Contexts importer/inference work, newer Contexts UI work and PR68 storage-grant repair. This patch does not add another model or trainer.

Reconciliation found that the audio app's neural idle guard checks legacy captures but misses the newer shared room/event capture intent. During a quiet shared capture, a candidate can promote and checkpoint, temporarily closing its microphone. The unmodified production controller reproduced 1,839 neural ticks, one checkpoint write and one microphone close before the new assertion failed.

Add an audio-local shared-learning-state accessor and a three-line early guard. Paused or awaiting/failed Save capture keeps priority. Successful Save, Cancel, or confirmed Discard clears the existing state and resumes normal one-time promotion/checkpointing. Model architecture, training, inference, cache format, shared/RF production source and storage-cleanup behavior remain unchanged.

Add a six-case real-app matrix covering room/event capture, quiet active/paused states, preparing and genuinely trained pre-promotion candidates, Cancel, failed Save then retry, and failed Save then confirmed Discard. Verify microphone ownership, no neural progress during capture, resumed training/checkpointing afterward, and unchanged authoritative event banks. Correct documentation to describe the existing second validation pass as all examples of eligible trained labels, not every saved label.

## Verification

- Full Spectrum: 52 normal and ASan/UBSan fixture executions passed before and after the fix.
- Final six-case shared-capture regression: separately passed normal and ASan/UBSan.
- Contexts: ten normal and ASan/UBSan executions passed on unchanged source.
- Storage lifecycle: two normal and ASan/UBSan executions passed after the fix.
- Shared-input safety: two normal and ASan/UBSan executions passed.
- Contexts contract: check plus four focused Python tests passed.
- Full Python aggregate: 269 tests passed.
- Whitespace/diff check passed; two independent source reviews found no blocking issue.

LeakSanitizer was disabled by the caller. Exact dependency pins, commands and logs are recorded in T040-reconciliation.md and the accompanying evidence directory. Generated-PCM classifier outcomes are regression evidence, not physical acoustic accuracy.

## Still required before qualified delivery

- Publication authorization for this branch, independent of other pending branch approvals.
- Recheck main/active owners, target compilation and exact product integration before proposing an installable candidate.
- Coordinate a new package version with the canonical owner; manifests and frozen packages were not changed by this local source patch.
- On the identified Watch build, verify real taught positives/confusing nonmatches, unknown fallback, capture interruption/resumption and persistence, plus on-device resource cost. No physical or target-build qualification has occurred.
- No claim that this reproduces the historical reported capture fault; no new speaker identity, command execution or radio-signature scope.
