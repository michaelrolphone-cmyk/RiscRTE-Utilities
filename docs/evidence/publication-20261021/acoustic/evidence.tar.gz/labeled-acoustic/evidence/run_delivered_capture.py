import os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'Utilities-Released'
system=root.parents[1]/'acoustic-neural/RiscRTE-System-Apps'
out=Path(__file__).resolve().parent/'delivered-tests';out.mkdir(exist_ok=True)
fixtures=['tests/spectrum_signatures_test.c','tests/spectrum_room_learning_test.c','test/native_apps/spectrum_signature_app_test.c','test/native_apps/spectrum_temporal_app_test.c','test/native_apps/spectrum_live_learning_test.c','test/native_apps/spectrum_capture_cadence_test.c']
for fixture in fixtures:
 for sanitized in [False,True]:
  target=out/(Path(fixture).stem+('-san' if sanitized else ''))
  flags=['-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer','-no-pie'] if sanitized else []
  subprocess.run(['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror',*flags,'-I'+str(system/'lib/PortableApps/include'),'-I'+str(system/'lib/NativeApps/include'),str(root/fixture),'-lm','-o',str(target)],check=True,timeout=120)
  subprocess.run([str(target)],check=True,timeout=90,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'})
print('Delivered capture: 6 fixtures / 12 normal and ASan+UBSan executions passed')
