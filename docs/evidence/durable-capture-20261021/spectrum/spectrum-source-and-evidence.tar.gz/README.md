Original source and technical evidence recovery.

This incremental bundle preserves original commit identities. It requires base 6b2047500905f8f45087cb49989103a926fc5c63; obtain that source prerequisite before importing. GitHub capture commits have equivalent source trees but distinct metadata.

Tests are scoped historical observations, not firmware release or hardware acceptance. Failed and blocked logs are retained. Build products and private tracker/account/conversation data are excluded.
