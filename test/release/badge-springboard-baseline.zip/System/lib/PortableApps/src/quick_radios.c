#include "PortableQuickRadios.h"
#include "PortableStageLog.h"
static bool bind(const risc_runtime_api_v1*rt,risc_runtime_capability_v1*g,const char*name,unsigned instance) {
 *g=(risc_runtime_capability_v1){.struct_size=sizeof(*g)};return rt->acquire(name,1,instance,g);
}
static const portable_bluetooth_control_v1* ble(const risc_runtime_capability_v1*g) {
 const portable_bluetooth_control_v1*b=g->api;
 return b&&b->api_version==1&&b->struct_size>=sizeof(*b)&&b->set_enabled&&b->status?b:NULL;
}
static const wifi_api_v1* wifi(const risc_runtime_capability_v1*g) {
 const wifi_api_v1*w=g->api;
 return w&&w->api_version==1&&w->struct_size>=sizeof(*w)&&w->status&&w->disconnect_checked?w:NULL;
}
static void reflect(const pqa_radios*s,pqa_state*u) {
 u->radio_controls=true;u->radios_valid=s->valid&&s->available;
 u->wifi_enabled=!!(s->flags&PORTABLE_RADIO_WIFI);u->bluetooth_enabled=!!(s->flags&PORTABLE_RADIO_BLUETOOTH);u->airplane=!!(s->flags&PORTABLE_RADIO_AIRPLANE);
}
static bool set_hardware(const risc_runtime_api_v1*rt,const wifi_api_v1*w,const portable_bluetooth_control_v1*b,uint8_t flags) {
 (void)rt;
 portable_stage_log(rt,"radio-policy",flags&PORTABLE_RADIO_WIFI?"wifi=allowed auto-connect=not-requested":"wifi=off");
 portable_stage_log(rt,"bluetooth-request",flags&PORTABLE_RADIO_BLUETOOTH?"enabled=yes":"enabled=no");
 if(!(flags&PORTABLE_RADIO_WIFI) && (!w->disconnect_checked(w->context)||w->status(w->context)!=WIFI_LINK_DOWN)){
  portable_stage_log(rt,"wifi-policy-result","result=failed off=unconfirmed");
  return false;
 }
 if(!(flags&PORTABLE_RADIO_WIFI))portable_stage_log(rt,"wifi-policy-result","result=ok state=down");
 uint8_t actual=PORTABLE_BLUETOOTH_RETAINED;
 bool ok=b->set_enabled(b->context,!!(flags&PORTABLE_RADIO_BLUETOOTH)) && b->status(b->context,&actual) && actual==((flags&PORTABLE_RADIO_BLUETOOTH)?PORTABLE_BLUETOOTH_ON:PORTABLE_BLUETOOTH_OFF);
 if(ok)portable_stage_log(rt,"bluetooth-result",actual==PORTABLE_BLUETOOTH_ON?"state=on":"state=off");
 else portable_stage_log(rt,"bluetooth-result","result=failed requested-state=unconfirmed");
 return ok;
}
bool pqa_radios_load(pqa_radios*s,pqa_state*u,const risc_runtime_api_v1*rt) {
 *s=(pqa_radios){0};risc_runtime_capability_v1 kg,wg,bg;
 (void)bind(rt,&kg,RISC_KEY_VALUE_CAPABILITY,1);unsigned loaded=portable_radio_load_result(kg.api,&s->flags);
 s->valid=loaded<=PORTABLE_RADIO_DEFAULT;
 portable_stage_log(rt,"radio-preferences",loaded==PORTABLE_RADIO_DEFAULT?"result=missing defaults=wifi-allowed,bluetooth-off":
     loaded==PORTABLE_RADIO_PERSISTED?"result=persisted":loaded==PORTABLE_RADIO_INVALID?"result=corrupt forcing=off":"result=unavailable forcing=off");
 if(kg.api&&!rt->release(&kg))return false;
 (void)bind(rt,&wg,"net.wifi",15);(void)bind(rt,&bg,"bluetooth.hci",16);
 const wifi_api_v1*w=wifi(&wg);const portable_bluetooth_control_v1*b=ble(&bg);
 /* An unreadable/corrupt desired state must not leave a previously enabled
  * controller running behind disabled controls. Prove both radios Off without
  * overwriting the bad record; failed cleanup retains the invocation. */
 s->available=w&&b;bool ok=!s->available||set_hardware(rt,w,b,s->valid?s->flags:0);
 if(!s->available)portable_stage_log(rt,"radio-policy-result","result=unavailable provider-missing-or-invalid");
#ifdef PORTABLE_DESK_CLOCK
 /* The new deferred foreground path treats unconfirmed radio cleanup as
  * retained. Preserve these live grants for the adapter's retained stop. */
 if(!ok){u->error_flags|=PQA_ERROR_RADIO;return false;}
#endif
 if(!s->valid)u->error_flags|=PQA_ERROR_RADIO|PQA_ERROR_SAVE;
 if(bg.api&&!rt->release(&bg)){
#ifdef PORTABLE_DESK_CLOCK
  return false;
#else
  ok=false;
#endif
 }
 if(wg.api&&!rt->release(&wg))ok=false;
 reflect(s,u);if(!ok)u->error_flags|=PQA_ERROR_RADIO;
 return ok;
}
#ifdef PORTABLE_QUICK_ATOMIC_PREFERENCES
bool pqa_radios_apply_user(pqa_radios*s,pqa_state*u,const risc_runtime_api_v1*rt,uint32_t actions,
                          pqa_user_preference_save save,void *context,bool(*safe)(void*)) {
#else
bool pqa_radios_apply(pqa_radios*s,pqa_state*u,const risc_runtime_api_v1*rt,uint32_t actions) {
#endif
 if(!(actions&(PQA_WIFI|PQA_BLUETOOTH|PQA_AIRPLANE)))return true;
 if(!s->valid||!s->available){u->error_flags|=PQA_ERROR_RADIO;return true;}
 uint8_t next=s->flags;
 if(actions&PQA_AIRPLANE) {
  if(next&PORTABLE_RADIO_AIRPLANE)next=(uint8_t)((next>>3)&3u);
  else next=(uint8_t)(PORTABLE_RADIO_AIRPLANE|((next&3u)<<3));
 } else {
  uint8_t bit=(actions&PQA_WIFI)?PORTABLE_RADIO_WIFI:PORTABLE_RADIO_BLUETOOTH;
  next^=bit;
  if(next&bit)next&=(uint8_t)~(PORTABLE_RADIO_AIRPLANE|PORTABLE_RADIO_PREVIOUS_WIFI|PORTABLE_RADIO_PREVIOUS_BLUETOOTH);
 }
 risc_runtime_capability_v1 wg,bg;
 (void)bind(rt,&wg,"net.wifi",15);(void)bind(rt,&bg,"bluetooth.hci",16);
#ifndef PORTABLE_QUICK_ATOMIC_PREFERENCES
 risc_runtime_capability_v1 kg;(void)bind(rt,&kg,RISC_KEY_VALUE_CAPABILITY,1);
#endif
 const wifi_api_v1*w=wifi(&wg);const portable_bluetooth_control_v1*b=ble(&bg);
 bool changed=w&&b&&set_hardware(rt,w,b,next);bool ok=true;
#ifdef PORTABLE_QUICK_ATOMIC_PREFERENCES
 const uint8_t record[]={0x51,1,next,(uint8_t)(next^0xa5)};
 bool saved=changed&&save&&save(context,PORTABLE_RADIO_KEY,record,4,NULL);
 if(!safe||!safe(context))return false;
 if(saved)
#else
 if(changed&&portable_radio_save(kg.api,next))
#endif
 {s->flags=next;u->error_flags&=~(PQA_ERROR_RADIO|PQA_ERROR_SAVE);portable_stage_log(rt,"radio-save","result=confirmed");}
 else {
  portable_stage_log(rt,"radio-save","result=failed restoring=previous-policy");
  /* An explicit operation failed. Prove restoration; otherwise retain the
   * invocation instead of claiming Off or proceeding into native sleep. */
  u->error_flags|=PQA_ERROR_RADIO|PQA_ERROR_SAVE;
  ok=w&&b&&set_hardware(rt,w,b,s->flags);
 }
#ifndef PORTABLE_QUICK_ATOMIC_PREFERENCES
 if(kg.api&&!rt->release(&kg))ok=false;
#endif
 if(bg.api&&!rt->release(&bg))ok=false;
 if(wg.api&&!rt->release(&wg))ok=false;
 reflect(s,u);return ok;
}
bool pqa_radios_suspend(const risc_runtime_api_v1*rt) {
 portable_stage_log(rt,"bluetooth-suspend","request=off");
 risc_runtime_capability_v1 g;if(!bind(rt,&g,"bluetooth.hci",16))return false;
 const portable_bluetooth_control_v1*b=ble(&g);uint8_t state=PORTABLE_BLUETOOTH_RETAINED;
 bool ok=b&&b->set_enabled(b->context,false)&&b->status(b->context,&state)&&state==PORTABLE_BLUETOOTH_OFF;
 portable_stage_log(rt,"bluetooth-suspend",ok?"result=ok state=off":"result=failed off=unconfirmed");
 return rt->release(&g)&&ok;
}
bool pqa_radios_resume(pqa_radios*s,pqa_state*u,const risc_runtime_api_v1*rt) {return pqa_radios_load(s,u,rt);}

#ifdef PORTABLE_QUICK_ATOMIC_PREFERENCES
/* Shared entry points cannot manufacture user authorization. */
bool pqa_radios_apply(pqa_radios*s,pqa_state*u,const risc_runtime_api_v1*rt,uint32_t actions) {
 if(actions&(PQA_WIFI|PQA_BLUETOOTH|PQA_AIRPLANE)){u->error_flags|=PQA_ERROR_SAVE|PQA_ERROR_RADIO;return true;}
 (void)s;(void)rt;return true;
}
#endif
